<template>
    <div>
        <home-navbar />
        <router-view></router-view>
    </div>
</template>

<script>
import HomeNavbar from './HomeNavbar.vue'
export default {
  components: { HomeNavbar },
    name: 'HomeVue'
}
</script>