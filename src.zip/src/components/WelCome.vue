<template>
    <div>
        <HomeNavbar/>
        
    </div>
</template>
<script>
import HomeNavbar from './HomeNavbar.vue'
export default {
    name:'WelCome',
    components:{
  HomeNavbar
 }
}
</script>