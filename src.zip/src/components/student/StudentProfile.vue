<template>
    <div>
        <div class="vh-100 d-flex justify-content-center align-items-center">
            <h2>Student Profile</h2>

            <button @click="login">Login</button>



          </div>
          <div class="bg-dark text-white">
            <p class="text-center p-4 m-0">Footer Content</p>
          </div>
    </div>
</template>
<script>
export default {
    name:'StudentProfile',
    methods:{
      login(){
        this.$router.push('/student')
      }
    }
}
</script>