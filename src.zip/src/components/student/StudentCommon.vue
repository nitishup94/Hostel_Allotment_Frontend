<template>
    <div>
        <StudentNav />
        <router-view></router-view>
    </div>
</template>

<script>
import StudentNav from './StudentNav.vue';
export default {
  components: { StudentNav },
    name: 'StudentCommon'
}
</script>