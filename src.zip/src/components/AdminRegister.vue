<template>
    <div>
        <div class="vh-100 d-flex justify-content-center align-items-center">
            <h2>Admin Register</h2>
          </div>
          <div class="bg-dark text-white">
            <p class="text-center p-4 m-0">Footer Content</p>
          </div>
    </div>
</template>
<script>
export default {
    name:'AdminRegister',
}
</script>