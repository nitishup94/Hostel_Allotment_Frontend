import HomePage from './components/HomePage.vue'
import StudentLogin from './components/StudentLogin.vue'
import HomeVue from './components/HomeVue.vue'
import AdminRegister from './components/AdminRegister.vue'
import StudentInfo from './components/student/StudentInfo.vue'
import StudentCommon from './components/student/StudentCommon.vue'
import StudenProfile from './components/student/StudentProfile.vue'
export default [
    // { path:'/App',component:UserComp,children:[{path:'login',component:LoginPage}, { path:'Register',component:RegisterPage}]},
    

    {path:'/',component:HomeVue,children:[
        {path:'', component: HomePage},
        {path:'Student_login',component:StudentLogin},
        {path:'Admin_register',component:AdminRegister},
    ]},
    {path:'/student',component:StudentCommon, children: [
        {path: '', component:StudentInfo},
        {path: 'profile', component:StudenProfile}
    ]}

   
   ]